import random
rand_num = random.randint(1,10)  
def factorial_fn (rand_num):
    factorial = 1
    for i in range(1,rand_num + 1):
       factorial = factorial*i
    print("The factorial of",rand_num,"is",factorial)

factorial_fn(rand_num)
